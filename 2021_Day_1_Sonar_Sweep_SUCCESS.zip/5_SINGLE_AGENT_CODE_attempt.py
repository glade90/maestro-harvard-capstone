import sys

# Read input file provided via command line argument
with open(sys.argv[1]) as f:
    lines = [line.strip() for line in f if line.strip()]

# Convert lines to integers
depths = list(map(int, lines))

# Count how many measurements are larger than the previous measurement
count_increases = 0
for i in range(1, len(depths)):
    if depths[i] > depths[i - 1]:
        count_increases += 1

print(count_increases)