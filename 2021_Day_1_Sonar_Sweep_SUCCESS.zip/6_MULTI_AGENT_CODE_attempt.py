import sys

with open(sys.argv[1]) as f:
    prev_measurement = None
    count = 0
    for line in f:
        line = line.strip()
        if not line:
            continue
        measurement = int(line)
        if prev_measurement is not None and measurement > prev_measurement:
            count += 1
        prev_measurement = measurement
print(count)